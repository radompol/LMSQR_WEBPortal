import { Button, Form, Modal } from "react-bootstrap";
import { FIREBASE_AUTH, FIRESTORE_DB } from "../../Utils/Firebase_config";
import React, { useEffect, useState } from "react";
import {
  collection,
  doc,
  getDocs,
  onSnapshot,
  query,
  updateDoc,
  where,
} from "firebase/firestore";

import QRCode from "react-qr-code";
import { onAuthStateChanged } from "firebase/auth";
import { useNavigate } from "react-router-dom";

function Loans({ setLoggedIn }) {
  const navigate = useNavigate();
  const [list, setList] = useState([]);
  const [list_, setList_] = useState([]);
  const [sellerList, setSellerList] = useState([]);
  const [loanInfo, setLoanInfo] = useState({});
  const [show, setShow] = useState(false);
  const [isSelect, setIsSelect] = useState(false);
  const [isProceedToLoan, setIsProceedToLoan] = useState(false);
  const [isViewLoan, setIsViewLoan] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  useEffect(() => {
    const auth = onAuthStateChanged(FIREBASE_AUTH, (user) => {
      if (user) {
        setLoggedIn(true);
        //navigate('/home')
      } else {
        setLoggedIn(false);
        navigate("/");
        console.log("no Account logged in");
      }
    });
    return auth;
  });
  useEffect(() => {
    window.onpopstate = function (event) {
      // Redirect the user to a specific location
      navigate(window.localStorage.getItem("what_path"));
    };
    const q = query(
      collection(FIRESTORE_DB, "products"),
      where("status", "==", "pending")
    );
    const unsubscribe = onSnapshot(
      q,
      (querySnapshot) => {
        //resolve(querySnapshot)
        let list = querySnapshot.docs.map((res) => {
          return {
            status: res.data().status,
            productID: res.id,
            productName: res.data().name,
            sellerID: res.data().userId,
            productDescription: res.data().desc,
            productImage: res.data().pic,
          };
        });
        setList(list);
        setList_(list);
        // console.log(list)
      },
      () => {
        return unsubscribe();
      },
      (err) => {
        console.log(err);
      }
    );
    const q1 = query(
      collection(FIRESTORE_DB, "users"),
      where("userType", "!=", 1)
    );
    const unsubscribe1 = onSnapshot(
      q1,
      (querySnapshot) => {
        //resolve(querySnapshot)
        let list = querySnapshot.docs.map((res) => {
          return res;
        });
        //console.log(list);
        setSellerList(list);
      },
      () => {
        return unsubscribe1();
      },
      (err) => {
        console.log(err);
      }
    );
  }, []);
  const getUserData = (list, id) => {
    var data = {};
    list.forEach((element) => {
      if (element.id == id) {
        data = element;
      }
    });
    return data.data();
  };
  const removeHandler = async (id, remarks_removed) => {
    const ref = doc(FIRESTORE_DB, "products", id);
    await updateDoc(ref, {
      status: "archived",
      remarks_removed,
    });
  };
  const approveHandler = async (id) => {
    const ref = doc(FIRESTORE_DB, "products", id);
    await updateDoc(ref, {
      status: "active",
    });
  };
  const filterHandler = (text) => {
    console.log(text);
    try {
      if (text !== "") {
        let temp = list.filter((res) => {
          console.log(res.sellerID === text);
          if (res.sellerID === text) {
            return res;
          }
        });
        if (temp.length <= 0) {
          alert("No products displayed by this store.");
          temp = list_;
        }
        setList(temp);
      } else {
        setList(list_);
      }
    } catch (err) {
      alert(err);
    }
  };
  const searchHandler = (text) => {
    try {
      if (text !== "") {
        setList(
          list.filter((res) => {
            if (
              res.productName.toUpperCase().match(text.toUpperCase()) ||
              res.productDescription.toUpperCase().match(text.toUpperCase())
            ) {
              return res;
            }
          })
        );
      } else {
        setList(list_);
      }
    } catch (err) {
      alert(err);
    }
  };
  return (
    <div className="mx-2 mt-2">
      <div className="card">
        <div className="card-header">
          <b> LOAN LIST</b>

          <a onClick={handleShow} className="btn btn-primary float-end">
            <i className="fa fa-plus" aria-hidden="true"></i> Add Loan
            Information
          </a>
        </div>
        <div className="card-body">
          <div className="table-responsive table-bordered">
            <table class="table ">
              <thead className="table-light">
                <tr>
                  <th scope="col">LID</th>
                  <th scope="col">Borrower Name</th>
                  <th scope="col">Amount</th>
                  <th scope="col">Type</th>
                  <th scope="col">Loan For</th>
                  <th scope="col">Status</th>
                  <th scope="col">
                    <i className="fa fa-cogs" aria-hidden="true"></i> Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>R1C1</td>
                  <td>R1C2</td>
                  <td>R1C3</td>
                  <td>R1C2</td>
                  <td>R1C3</td>
                  <td>
                    <span className="badge bg-danger text-white">Active</span>
                  </td>

                  <td>
                    <i
                      onClick={() => {
                        setIsViewLoan(true);
                      }}
                      style={{ cursor: "pointer" }}
                      class="fa fa-eye text-primary "
                      aria-hidden="true"
                    ></i>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Modal size={"lg"} show={isViewLoan} onHide={() => setIsViewLoan(false)}>
        <Modal.Header className="bg-primary">
          <Modal.Title className="text-white">Loan Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className="col">
              <QRCode
                size={256}
                style={{ height: "auto", width: 200 }}
                value={"ID:123912421321"}
              />
            </div>
            <div className="col">
              <div>
                <p className="my-0">
                  Loan ID: <b>1931023781231</b>
                </p>
                <p className="my-0">
                  Borrower : <b>Example user 1</b>
                </p>
                <p className="my-0">
                  Amount : <b>PHP 200.00</b>
                </p>
                <p className="my-0">
                  In Words : <b>Two Hundred Pesos</b>
                </p>
              </div>
              <div className="mt-2 mx-3">
                <p>LOAN BALANCE: </p>
                <span style={{ fontWeight: "bold", fontSize: 40 }}>
                  P 200.00
                </span>
              </div>
            </div>
          </div>

          {/* //LISt of Collections */}
          <div className="mx-2 mt-2">
            <div className="card">
              <div className="card-header">
                <b>PAYMENT LIST</b>
              </div>
              <div className="card-body">
                <div className="table-responsive table-bordered">
                  <table class="table ">
                    <thead className="table-light">
                      <tr>
                        <th scope="col">PID</th>
                        <th scope="col">Collector</th>

                        <th scope="col">Payment Amount</th>
                        <th scope="col">Date Applied</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>R1C1</td>
                        <td>Collector Name</td>

                        <td>R1C3</td>
                        <td>R1C1</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setIsViewLoan(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header className="bg-primary">
          <Modal.Title className="text-white">
            {isProceedToLoan ? "Loan Info Created" : "Add Loan Info"}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {isProceedToLoan ? (
            <div className="row">
              <div className="col">
                <div
                  style={{
                    height: "auto",
                    maxWidth: 64,
                    width: "100%",
                  }}
                >
                  <QRCode
                    size={256}
                    style={{ height: "auto", width: 150 }}
                    value={"ID:123912421321"}
                  />
                </div>
              </div>
              <div className="col">
                <div>
                  <p className="my-0">
                    Loan ID: <b>1931023781231</b>
                  </p>
                  <p className="my-0">
                    Borrower : <b>Example user 1</b>
                  </p>
                  <p className="my-0">
                    Amount : <b>PHP 200.00</b>
                  </p>
                  <p className="my-0">
                    In Words : <b>Two Hundred Pesos</b>
                  </p>
                </div>
              </div>
            </div>
          ) : isSelect ? (
            <>
              <div className="row">
                <div className="col">
                  <button
                    onClick={() => {
                      setIsSelect(false);
                    }}
                    className="btn btn-danger form-control"
                  >
                    Cancel
                  </button>
                </div>
              </div>
              <div className="row">
                <div className="col">
                  <div className="d-flex m-2">
                    <input
                      placeholder="Search Borrower here..."
                      className="form-control"
                      type="text"
                    />
                    <i class="fa fa-search  p-2 border" aria-hidden="true"></i>
                  </div>
                </div>
              </div>

              <div className="table-responsive my-2">
                <table className="table table-striped table-bordered">
                  <thead>
                    <tr>
                      <td>Borrower ID</td>
                      <td>Name</td>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>RIo</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </>
          ) : (
            <>
              <div className="row">
                <button
                  onClick={() => {
                    setIsSelect(true);
                  }}
                  className="btn btn-primary"
                >
                  Select Borrower
                </button>
                <div className="col">
                  <label>Loan Type</label>
                  <Form.Select>
                    <option>Default select</option>
                  </Form.Select>
                </div>
              </div>
              <div className="row">
                <div className="col">
                  <table className="table ">
                    <thead>
                      <tr className="border-0">
                        <th colSpan={3}>Loan Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <label>Amount</label>
                          <input
                            className="form-control"
                            type={"number"}
                            value={0}
                            placeholder={"Enter Amount"}
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <label>Amount in Words</label>
                          <input
                            className="form-control"
                            type={"text"}
                            value={""}
                            placeholder={"Enter Amount"}
                          />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </Modal.Body>
        {isProceedToLoan ? (
          <>
            <Modal.Footer>
              <Button
                variant="primary"
                onClick={() => {
                  setIsProceedToLoan(false);
                  alert("Loan Successfully Added!");
                  handleClose();
                }}
              >
                Done
              </Button>
            </Modal.Footer>
          </>
        ) : !isSelect ? (
          <>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Close
              </Button>
              <Button
                variant="primary"
                onClick={() => {
                  setIsProceedToLoan(true);
                  alert("Loan Successfully Created!");
                }}
              >
                Create Loan Info
              </Button>
            </Modal.Footer>
          </>
        ) : null}
      </Modal>
    </div>
  );
}

export default Loans;

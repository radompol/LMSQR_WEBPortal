import React, { useEffect, useState } from "react";
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
} from "firebase/auth";

import Logo from "../../assets/Logo_main.jpg";
import swal from "sweetalert";
import { useNavigate } from "react-router-dom";

function Login({ setLoggedIn, setLoggedIn_ }) {
  const navigate = useNavigate();
  const [setter, setSetter] = useState(false);
  const [userDetails, setUserDetails] = useState({
    email: "",
    password: "",
  });
  useEffect(() => {
    const auth = onAuthStateChanged(getAuth(), (user) => {
      if (user) {
        console.log("user is logged in");
        navigate(window.localStorage.getItem("what_path"));
        setSetter(false);
      } else {
        setSetter(true);
        console.log("no Account logged in");
      }
    });
    return auth;
  });
  const handleSignIn = async (userDetails) => {
    signInWithEmailAndPassword(
      getAuth(),
      userDetails.email,
      userDetails.password
    )
      .then((user) => {
        console.log(user);
        //ADMIN
        if (userDetails.email) {
          if (
            userDetails.email
              .toLowerCase()
              .match("loanmanagementsystemwithqrcode@gmail.com".toLowerCase())
          ) {
            window.localStorage.setItem("access_type", 0);
            window.localStorage.setItem("what_path", "/home");
            navigate("/home");
            swal("Login Successfully!", "Welcome Admin", "success");
          } else {
            window.localStorage.setItem("access_type", 1);
            window.localStorage.setItem("what_path", "/borrower");
            navigate("/borrower");
            swal(
              "Login Successfully!",
              "Welcome to Borrower's Profile",
              "success"
            );
          }
          setLoggedIn_(false);
          setLoggedIn(true);
        } else {
          window.localStorage.setItem("loggedIn", "");
          alert("Email and password does not match.");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
  if (setter) {
    return (
      <div className="Auth-form-container">
        <div className="Auth-form">
          <div className={"Auth-form-content"}>
            <img className="mx-4" src={Logo} style={{ width: 300 }} />

            <div class="mb-3">
              <label for="" class="form-label">
                Email
              </label>
              <input
                type="email"
                class="form-control"
                name=""
                id=""
                aria-describedby="emailHelpId"
                placeholder="example@email.com"
                onChange={(evt) => {
                  setUserDetails((prev) => ({
                    ...prev,
                    email: evt.target.value,
                  }));
                }}
              />
              <div class="mb-3">
                <label for="" class="form-label">
                  Password
                </label>
                <input
                  type="password"
                  class="form-control"
                  name=""
                  id=""
                  onChange={(evt) => {
                    setUserDetails((prev) => ({
                      ...prev,
                      password: evt.target.value,
                    }));
                  }}
                  security={true}
                  placeholder=""
                />
                <button
                  class="btn btn-primary  form-control my-2"
                  onClick={() => {
                    handleSignIn(userDetails);
                  }}
                >
                  Login
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Login;

import { FIREBASE_AUTH, FIRESTORE_DB } from "../../Utils/Firebase_config";
import React, { useEffect, useState } from "react";
import {
  collection,
  doc,
  getDocs,
  onSnapshot,
  query,
  updateDoc,
  where,
} from "firebase/firestore";

import Userlist from "../Users/Userlist";
import { onAuthStateChanged } from "firebase/auth";
import { useNavigate } from "react-router-dom";

function Payments({ setLoggedIn }) {
  const navigate = useNavigate();
  const [list, setList] = useState([]);
  const [sellerList, setSellerList] = useState([]);
  const [sellerList_, setSellerList_] = useState([]);
  useEffect(() => {
    const auth = onAuthStateChanged(FIREBASE_AUTH, (user) => {
      if (user) {
        setLoggedIn(true);
        //navigate('/home')
      } else {
        setLoggedIn(false);
        navigate("/");
        console.log("no Account logged in");
      }
    });
    return auth;
  });
  useEffect(() => {
    window.onpopstate = function (event) {
      // Redirect the user to a specific location
      navigate(window.localStorage.getItem("what_path"));
    };

    const q1 = query(
      collection(FIRESTORE_DB, "users"),
      where("userType", "!=", 1)
    );
    const unsubscribe1 = onSnapshot(
      q1,
      (querySnapshot) => {
        //resolve(querySnapshot)
        let list = querySnapshot.docs.map((res) => {
          return res;
        });
        // console.log(list);
        setSellerList(list);
        setSellerList_(list);
      },
      () => {
        return unsubscribe1();
      },
      (err) => {
        console.log(err);
      }
    );
  }, []);
  const searchHandler = (text) => {
    try {
      if (text !== "") {
        let temp = sellerList.filter((res) => {
          if (
            res.data().storename.toUpperCase().match(text.toUpperCase()) ||
            res.data().email.toUpperCase().match(text.toUpperCase())
          ) {
            return res;
          }
        });
        if (temp <= 0) {
          temp = sellerList_;
        }
        setSellerList(temp);
      } else {
        setSellerList(sellerList_);
      }
    } catch (err) {
      alert(err);
    }
  };
  return (
    <div className="mx-2 mt-2">
      <div className="card">
        <div className="card-header">
          <b>PAYMENT LIST</b>
        </div>
        <div className="card-body">
          <div className="table-responsive table-bordered">
            <table class="table ">
              <thead className="table-light">
                <tr>
                  <th scope="col">PID</th>
                  <th scope="col">Collector</th>

                  <th scope="col">Payment Amount</th>
                  <th scope="col">Date Applied</th>
                  <th scope="col">
                    <i className="fa fa-cogs" aria-hidden="true"></i> Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>R1C1</td>
                  <td>Collector Name</td>

                  <td>R1C3</td>
                  <td>R1C1</td>
                  <td>
                    <span className="badge bg-success">
                      <i class="fa fa-check px-1" aria-hidden="true"></i>
                      Approve
                    </span>

                    <span className="badge bg-danger mx-2">
                      <i
                        className="fa fa-window-close px-1"
                        aria-hidden="true"
                      ></i>
                      Decline
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Payments;

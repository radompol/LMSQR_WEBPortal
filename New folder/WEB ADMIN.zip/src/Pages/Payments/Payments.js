import { FIREBASE_AUTH, FIRESTORE_DB } from "../../Utils/Firebase_config";
import React, { useEffect, useState } from "react";
import {
  collection,
  doc,
  getDocs,
  onSnapshot,
  query,
  updateDoc,
  where,
} from "firebase/firestore";

import Userlist from "../Users/Userlist";
import { onAuthStateChanged } from "firebase/auth";
import { useNavigate } from "react-router-dom";

function Payments({ setLoggedIn }) {
  const navigate = useNavigate();
  const [list, setList] = useState([]);
  const [collectionList_, setcollectionList_] = useState([]);
  const [collectionList, setcollectionList] = useState([]);
  const [collectionListR, setcollectionListR] = useState([]);
  useEffect(() => {
    const auth = onAuthStateChanged(FIREBASE_AUTH, (user) => {
      if (user) {
        setLoggedIn(true);
        //navigate('/home')
      } else {
        setLoggedIn(false);
        navigate("/");
        console.log("no Account logged in");
      }
    });
    return auth;
  });
  useEffect(() => {
    window.onpopstate = function (event) {
      // Redirect the user to a specific location
      navigate(window.localStorage.getItem("what_path"));
    };

    const q5 = query(
      collection(FIRESTORE_DB, "CollectionsList"),
      where("collectionStatus", "==", "pending")
    );
    const unsubscribe5 = onSnapshot(
      q5,
      (querySnapshot) => {
        //resolve(querySnapshot)
        let list = querySnapshot.docs.map((res) => {
          return { ...res.data(), id: res.id };
        });

        setcollectionList(list);
        setcollectionList_(list);
      },
      () => {
        return unsubscribe5();
      },
      (err) => {
        console.log(err);
      }
    );
    const q6 = query(
      collection(FIRESTORE_DB, "CollectionsList"),
      where("collectionStatus", "==", "received")
    );
    const unsubscribe6 = onSnapshot(
      q6,
      (querySnapshot) => {
        //resolve(querySnapshot)
        let list = querySnapshot.docs.map((res) => {
          return { ...res.data(), id: res.id };
        });

        setcollectionListR(list);
      },
      () => {
        return unsubscribe6();
      },
      (err) => {
        console.log(err);
      }
    );
  }, []);
  const searchHandler = (text) => {
    try {
    } catch (err) {
      alert(err);
    }
  };
  function confirmReceive(id) {
    let answer = window.confirm("Are you sure to confirm this collection?");
    if (answer) {
      let updateRef = doc(FIRESTORE_DB, "CollectionsList", id);
      updateDoc(updateRef, {
        collectionStatus: "Received",
      });
      alert("Confirmed Successfully!");
    }
  }
  function confirmRemove(id) {
    let answer = window.confirm(
      "Are you sure to remove this duplicate collection?"
    );
    if (answer) {
      let updateRef = doc(FIRESTORE_DB, "CollectionsList", id);
      updateDoc(updateRef, {
        collectionStatus: "Removed",
      });
      alert("Removed Successfully!");
    }
  }
  function getTotalCollected(list) {
    let total = 0;
    list.forEach((element) => {
      total =
        Number.parseFloat(total) + Number.parseFloat(element.amountCollected);
    });
    // console.log(total);
    return Number.parseFloat(total).toFixed(2);
  }
  return (
    <div className="mx-2 mt-2">
      <div className="card">
        <div className="card-header">
          <b>PAYMENT LIST</b>
        </div>
        <div className="card-body">
          <div className="table-responsive table-bordered">
            <table class="table ">
              <thead className="table-light">
                <tr>
                  <th scope="col">PID</th>
                  <th scope="col">Collector</th>
                  <th>Borrower</th>
                  <th>Loan Amount</th>
                  <th>Loan Balance</th>
                  <th scope="col">Payment Amount</th>
                  <th scope="col">Date Applied</th>
                  <th scope="col">
                    <i className="fa fa-cogs" aria-hidden="true"></i> Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {collectionList.map((res) => {
                  return (
                    <tr>
                      <td>{res.id}</td>
                      <td>
                        {res.collectorData.fname +
                          " " +
                          res.collectorData.lname}
                      </td>
                      <td>
                        {res.loanDetails.selectedCustomer.fname +
                          "" +
                          res.loanDetails.selectedCustomer.lname}
                      </td>
                      <td>{res.loanDetails.amountNumeric}</td>
                      <td>
                        {Number.parseFloat(res.loanDetails.amountNumeric) -
                          getTotalCollected(collectionListR)}
                      </td>
                      <td>{res.amountCollected}</td>
                      <td>{res.dateTimeAdded}</td>
                      <td>
                        <span
                          onClick={() => {
                            confirmReceive(res.id);
                          }}
                          style={{ cursor: "pointer" }}
                          className="badge bg-success"
                        >
                          <i class="fa fa-check px-1" aria-hidden="true"></i>
                          Receive
                        </span>
                        <span
                          onClick={() => {
                            confirmRemove(res.id);
                          }}
                          style={{ cursor: "pointer" }}
                          className="badge bg-danger"
                        >
                          <i class="fa fa-trash" aria-hidden="true"></i>
                          Remove
                        </span>

                        {/* <span className="badge bg-danger mx-2">
                          <i
                            className="fa fa-window-close px-1"
                            aria-hidden="true"
                          ></i>
                          Decline
                        </span> */}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Payments;
